// ��������� ��������
#include <iostream>
#include <stdlib.h>
using namespace std;
int main(){
 int s; int sl;
 cout<<"Vvedi sl: ";	cin>>sl;
 srand(sl);
  for(int i=1;i<5;i++){
	s = rand() % 2;
	cout<<s<<" ";
 }
 cout<<endl;
 int n = 2;  cout<<"n="<<n<<endl;
 int k = 1;
 int m;
 m=n & k;
 cout<<"m= "<<m<<endl;
 n=n >> 1;
 m=n & k;
 cout<<"m= "<<m<<endl;
 n=n >> 1;
 m=n & k;
 cout<<"m= "<<m<<endl;
 system("pause");
 return 0;
}
